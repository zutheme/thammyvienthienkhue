=== Porto Widgets ===

Register widgets for porto ecommerce theme.

version: 1.0.0